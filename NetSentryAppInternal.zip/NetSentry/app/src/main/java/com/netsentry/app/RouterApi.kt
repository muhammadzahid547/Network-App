
package com.netsentry.app

import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

// Pi-hole query-log ingestion. Read-only: the app only ever GETs the query log
// (and authenticates for v6). Supports both API styles:
//   v5: http://<ip>/admin/api.php?getAllQueries&auth=<TOKEN>
//   v6: POST http://<ip>/api/auth {"password": ...} -> X-FTL-SID -> GET /api/queries
object RouterApi {
    data class LanQuery(val ts: Long, val domain: String, val client: String)

    fun fetchPiHole(ip: String, token: String?, password: String?): List<LanQuery> {
        if (!password.isNullOrEmpty()) {
            try {
                val sid = post("http://$ip/api/auth", "{\"password\":${JSONObject.quote(password)}}")
                    ?.let { JSONObject(it).optJSONObject("session")?.optString("sid") }
                if (!sid.isNullOrEmpty()) {
                    val body = get("http://$ip/api/queries", mapOf("X-FTL-SID" to sid)) ?: return emptyList()
                    val arr = JSONObject(body).optJSONArray("queries") ?: return emptyList()
                    val out = ArrayList<LanQuery>()
                    for (i in 0 until arr.length()) {
                        val q = arr.getJSONObject(i)
                        out.add(LanQuery(q.optLong("timestamp", 0) * 1000, q.optString("domain", ""), q.optString("client", "")))
                    }
                    return out
                }
            } catch (e: Exception) { }
        }
        if (!token.isNullOrEmpty()) {
            try {
                val body = get("http://$ip/admin/api.php?getAllQueries&auth=$token") ?: return emptyList()
                val arr = JSONObject(body).optJSONArray("data") ?: return emptyList()
                val out = ArrayList<LanQuery>()
                for (i in 0 until arr.length()) {
                    val q = arr.getJSONObject(i)
                    out.add(LanQuery(q.optLong("timestamp", 0) * 1000, q.optString("domain", ""), q.optString("client", "")))
                }
                return out
            } catch (e: Exception) { }
        }
        return emptyList()
    }

    private fun get(url: String, headers: Map<String, String> = emptyMap()): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 5000; c.readTimeout = 8000
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        return try { c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
    }

    private fun post(url: String, body: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.connectTimeout = 5000; c.readTimeout = 8000
        c.outputStream.use { it.write(body.toByteArray()) }
        return try { c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
    }
}

// UDP syslog receiver. An OpenWrt router (or anything) can forward its log to
// the phone: dnsmasq DNS queries and DHCP leases appear as whole-network
// endpoint visibility with zero router packages installed beyond log forwarding.
object SyslogListener {
    @Volatile var running = false
    private var sock: DatagramSocket? = null

    fun start(onLine: (String) -> Unit) {
        if (running) return
        running = true
        thread {
            try {
                val s = DatagramSocket(514)
                sock = s
                val buf = ByteArray(8192)
                while (running) {
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        s.receive(p)
                        onLine(String(p.data, 0, p.length))
                    } catch (e: Exception) { if (!running) break }
                }
                s.close()
            } catch (e: Exception) { }
            running = false
        }
    }

    fun stop() {
        running = false
        try { sock?.close() } catch (e: Exception) { }
    }

    private val QUERY = Regex("""query\[[A-Z0-9]+\]\s+(\S+)\s+from\s+(\S+)""")
    private val BLOCKED = Regex("""(gravity|blocked).{0,40}?(\S+\.[a-z]{2,})\s+is\s+0\.0\.0\.0""")
    private val DHCPACK = Regex("""DHCPACK\([^)]*\)\s+(\d+\.\d+\.\d+\.\d+)\s+([0-9a-fA-F:]{17})""")

    // Returns a parsed event: Pair(kind, payload)
    //   ("dns", "client|domain")  ("block", "client|domain")  ("dhcp", "ip|mac")
    fun parse(line: String): Triple<String, String, String>? {
        QUERY.find(line)?.let { m -> return Triple("dns", m.groupValues[2], m.groupValues[1].lowercase()) }
        BLOCKED.find(line)?.let { m -> return Triple("block", "?", m.groupValues[2].lowercase()) }
        DHCPACK.find(line)?.let { m -> return Triple("dhcp", m.groupValues[1], m.groupValues[2].uppercase()) }
        return null
    }
}
