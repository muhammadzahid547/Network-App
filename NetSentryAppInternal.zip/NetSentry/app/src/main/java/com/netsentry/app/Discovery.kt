
package com.netsentry.app

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Handler
import android.os.Looper
import java.net.DatagramPacket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.MulticastSocket
import java.net.SocketTimeoutException
import java.net.URL
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.CopyOnWriteArrayList
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

// Read-only LAN fingerprinting. No configuration changes anywhere:
// listens to mDNS/SSDP announcements devices already broadcast, and only
// connects out to read public banners/certs (like a browser would).
object Discovery {

    // ---- SSDP / UPnP: listen for what devices announce on the LAN ----
    fun ssdp(timeoutMs: Int = 3000): List<String> {
        val found = LinkedHashSet<String>()
        var ms: MulticastSocket? = null
        try {
            ms = MulticastSocket()
            ms.timeToLive = 2
            val req = ("M-SEARCH * HTTP/1.1\r\n" +
                "HOST: 239.255.255.250:1900\r\n" +
                "MAN: \"ssdp:discover\"\r\n" +
                "MX: 1\r\n" +
                "ST: ssdp:all\r\n\r\n").toByteArray()
            ms.send(DatagramPacket(req, req.size, InetAddress.getByName("239.255.255.250"), 1900))
            val buf = ByteArray(2048)
            val end = System.currentTimeMillis() + timeoutMs
            ms.soTimeout = 400
            while (System.currentTimeMillis() < end) {
                try {
                    val p = DatagramPacket(buf, buf.size)
                    ms.receive(p)
                    val s = String(p.data, 0, p.length)
                    val server = s.lineSequence().firstOrNull { it.startsWith("SERVER:", true) }
                        ?.substringAfter(':')?.trim()
                    val loc = s.lineSequence().firstOrNull { it.startsWith("LOCATION:", true) }
                        ?.substringAfter(':')?.trim()
                    val entry = listOfNotNull(server, loc).joinToString(" - ")
                    if (entry.isNotEmpty()) found.add(entry)
                } catch (e: SocketTimeoutException) { }
            }
        } catch (e: Exception) { } finally { try { ms?.close() } catch (e: Exception) { } }
        return found.toList()
    }

    // ---- mDNS/Bonjour via Android NSD (no permission needed) ----
    fun nsd(ctx: Context, onResult: (String) -> Unit, done: () -> Unit) {
        val types = listOf(
            "_googlecast._tcp", "_ipp._tcp", "_printer._tcp", "_http._tcp",
            "_smb._tcp", "_homekit._tcp", "_spotify-connect._tcp", "_esphome._tcp"
        )
        val nsd = ctx.getSystemService(Context.NSD_SERVICE) as NsdManager
        val seen = CopyOnWriteArrayList<String>()
        val listeners = mutableListOf<NsdManager.DiscoveryListener>()
        val lock = Any()
        var stopped = false
        fun stopOne() {
            synchronized(lock) { if (!stopped) { stopped = true; done() } }
        }
        types.forEach { type ->
            val l = object : NsdManager.DiscoveryListener {
                override fun onServiceFound(info: NsdServiceInfo) {
                    val s = "${info.serviceName} (${info.serviceType})"
                    if (!seen.contains(s)) { seen.add(s); onResult(s) }
                }
                override fun onServiceLost(info: NsdServiceInfo) {}
                override fun onDiscoveryStarted(t: String) {}
                override fun onDiscoveryStopped(t: String) {}
                override fun onStartDiscoveryFailed(t: String, e: Int) {}
                override fun onStopDiscoveryFailed(t: String, e: Int) {}
            }
            listeners.add(l)
            try { nsd.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, l) }
            catch (e: Exception) { }
        }
        Handler(Looper.getMainLooper()).postDelayed({
            listeners.forEach { try { nsd.stopServiceDiscovery(it) } catch (e: Exception) { } }
            stopOne()
        }, 4000)
    }

    // ---- TLS certificate CN of a device: strong vendor/model fingerprint ----
    fun tlsCn(host: String, port: Int): String? {
        return try {
            val tm = object : X509TrustManager {
                override fun checkClientTrusted(c: Array<X509Certificate>, a: String) {}
                override fun checkServerTrusted(c: Array<X509Certificate>, a: String) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
            }
            val ctx = SSLContext.getInstance("TLS").apply { init(null, arrayOf<TrustManager>(tm), SecureRandom()) }
            val s = ctx.socketFactory.createSocket(host, port) as SSLSocket
            s.soTimeout = 4000
            s.startHandshake()
            val cn = s.session.peerCertificates[0]?.let { (it as X509Certificate).subjectX500Principal.name }
            s.close()
            cn
        } catch (e: Exception) { null }
    }

    // ---- HTTP banner / title grab ----
    fun httpBanner(ip: String): String? {
        try {
            val c = URL("http://$ip/").openConnection() as HttpURLConnection
            c.connectTimeout = 2500
            c.readTimeout = 2500
            c.instanceFollowRedirects = true
            val server = c.getHeaderField("Server")
            val body = c.inputStream.bufferedReader().readText().take(8192)
            val title = Regex("<title>(.*?)</title>", RegexOption.IGNORE_CASE)
                .find(body)?.groupValues?.get(1)?.trim()
            c.disconnect()
            val parts = listOfNotNull(server?.let { "Server: $it" }, title?.let { "Title: $it" })
            if (parts.isNotEmpty()) return parts.joinToString(" - ")
        } catch (e: Exception) { }
        return null
    }
}
