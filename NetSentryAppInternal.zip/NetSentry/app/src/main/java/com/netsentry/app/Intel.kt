
package com.netsentry.app

import kotlin.math.ln

// On-device endpoint reputation. No external lookups: everything runs offline
// against embedded lists + heuristics. Extend the lists freely, or import a
// full blocklist (StevenBlack/URLhaus style) from CSV later.
object Intel {

    private val TRACKER_SUFFIXES = listOf(
        "doubleclick.net", "google-analytics.com", "googletagmanager.com",
        "graph.facebook.com", "app-measurement.com", "crashlytics.com",
        "adjust.com", "appadjust.io", "mixpanel.com", "appcenter.ms",
        "umeng.com", "appsflyer.com", "flurry.com", "scorecardresearch.com"
    )

    private val MINER_SUFFIXES = listOf(
        "coinhive.com", "minergate.com", "nanopool.org", "minexmr.com",
        "supportxmr.com", "xmrpool.eu"
    )

    private val BAD_SUFFIXES = listOf(
        "gandcrab.bit" // seed entry — import a real blocklist to expand
    )

    fun classify(domain: String?): String {
        if (domain.isNullOrEmpty()) return "ok"
        val d = domain.lowercase()
        for (s in BAD_SUFFIXES) if (d == s || d.endsWith(".$s")) return "malware"
        for (s in MINER_SUFFIXES) if (d == s || d.endsWith(".$s")) return "miner"
        for (s in TRACKER_SUFFIXES) if (d == s || d.endsWith(".$s")) return "tracker"
        if (isDga(d)) return "dga"
        return "ok"
    }

    fun entropy(s: String): Double {
        if (s.isEmpty()) return 0.0
        val f = HashMap<Char, Int>()
        s.forEach { f[it] = (f[it] ?: 0) + 1 }
        val n = s.length.toDouble()
        var h = 0.0
        for (c in f.values) { val p = c / n; h -= p * (ln(p) / ln(2.0)) }
        return h
    }

    // DGA heuristic: long random-looking second-level label, low vowel ratio,
    // high character entropy. Tuned to avoid flagging short brandable names.
    fun isDga(domain: String): Boolean {
        val sld = domain.substringBeforeLast('.').substringBeforeLast('.')
        if (sld.length < 10) return false
        if (sld.all { it.isDigit() }) return false
        val vowels = sld.count { it.lowercaseChar() in "aeiou" }
        val vowelRatio = vowels.toDouble() / sld.length
        return entropy(sld) > 3.6 && vowelRatio < 0.25
    }
}
