
package com.netsentry.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import java.io.File
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var pager: ViewPager2

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        NotificationHelper.ensureChannels(this)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val tabs = findViewById<TabLayout>(R.id.tabs)
        pager = findViewById(R.id.pager)
        pager.adapter = PagerAdapter(this)
        TabLayoutMediator(tabs, pager) { tab, pos ->
            tab.text = when (pos) { 0 -> "Endpoints"; 1 -> "Devices"; else -> "Status" }
        }.attach()
    }

    fun startVpn() {
        val intent = VpnService.prepare(this)
        if (intent != null) startActivityForResult(intent, REQ_VPN) else doStartVpn()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VPN && resultCode == RESULT_OK) doStartVpn()
    }

    private fun doStartVpn() {
        ContextCompat.startForegroundService(
            this, Intent(this, NetWatchService::class.java).setAction(NetWatchService.ACTION_START)
        )
    }

    fun stopVpn() {
        startService(Intent(this, NetWatchService::class.java).setAction(NetWatchService.ACTION_STOP))
    }

    class PagerAdapter(fa: FragmentActivity) : FragmentStateAdapter(fa) {
        override fun getItemCount() = 3
        override fun createFragment(pos: Int): Fragment = when (pos) {
            0 -> EndpointsFragment(); 1 -> DevicesFragment(); else -> StatusFragment()
        }
    }

    companion object { const val REQ_VPN = 100 }
}

// ---------------- Endpoints tab ----------------

class EndpointsFragment : Fragment() {
    private lateinit var adapter: EndpointAdapter
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { reload(); handler.postDelayed(this, 3000) }
    }

    override fun onCreateView(inflater: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val v = inflater.inflate(R.layout.frag_list, c, false)
        val rv = v.findViewById<RecyclerView>(R.id.list)
        rv.layoutManager = LinearLayoutManager(context)
        adapter = EndpointAdapter()
        rv.adapter = adapter
        return v
    }

    override fun onResume() { super.onResume(); handler.post(tick) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(tick) }

    private fun reload() {
        val ctx = context ?: return
        thread {
            val data = EndpointDb(ctx).recent(500)
            activity?.runOnUiThread {
                adapter.data = data
                adapter.notifyDataSetChanged()
                view?.findViewById<View>(R.id.empty)?.visibility =
                    if (data.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }
}

class EndpointAdapter : RecyclerView.Adapter<EndpointAdapter.VH>() {
    var data: List<Endpoint> = emptyList()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.title)
        val sub: TextView = v.findViewById(R.id.sub)
        val flag: TextView = v.findViewById(R.id.flag)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_endpoint, p, false))

    override fun getItemCount() = data.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val e = data[pos]
        h.title.text = if (e.domain != null) "${e.domain}  ->  ${e.dst}:${e.dport}"
                       else "${e.dst}:${e.dport}"
        val time = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date(e.ts))
        val src = if (e.src != "phone") " · from ${e.src}" else ""
        val tag = if (e.transport == "lan") " · LAN (router)" else ""
        h.sub.text = "$time · ${e.transport}$tag · ${e.proto}$src"
        if (e.flag != "ok") {
            h.flag.visibility = View.VISIBLE
            h.flag.text = e.flag.uppercase()
            h.flag.setTextColor(when (e.flag) {
                "malware", "dga" -> Color.parseColor("#C62828")
                "miner" -> Color.parseColor("#EF6C00")
                else -> Color.parseColor("#546E7A")
            })
        } else {
            h.flag.visibility = View.GONE
        }
    }
}

// ---------------- Devices tab ----------------

class DevicesFragment : Fragment() {
    private lateinit var adapter: DeviceAdapter

    override fun onCreateView(inflater: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val v = inflater.inflate(R.layout.frag_list, c, false)
        val rv = v.findViewById<RecyclerView>(R.id.list)
        rv.layoutManager = LinearLayoutManager(context)
        adapter = DeviceAdapter()
        rv.adapter = adapter
        val action = v.findViewById<Button>(R.id.action)
        action.visibility = View.VISIBLE
        action.text = "Deep scan (mDNS / SSDP / banners)"
        action.setOnClickListener { deepScan() }
        v.findViewById<View>(R.id.empty)?.visibility = View.VISIBLE
        scan()
        return v
    }

    private fun scan() {
        val ctx = context ?: return
        Toast.makeText(ctx, "Scanning LAN...", Toast.LENGTH_SHORT).show()
        thread {
            val found = LanScanner.scan(ctx)
            val store = DeviceStore(ctx)
            val known = store.macSet()
            val fresh = found.filter { it.mac != "?" && it.mac !in known }
            store.addAll(found)
            activity?.runOnUiThread {
                adapter.data = found
                adapter.newMacs = fresh.map { it.mac }.toSet()
                adapter.notes = emptyMap()
                adapter.services = emptyList()
                adapter.notifyDataSetChanged()
                view?.findViewById<View>(R.id.empty)?.visibility =
                    if (found.isEmpty()) View.VISIBLE else View.GONE
                if (fresh.isNotEmpty()) {
                    NotificationHelper.alert(
                        ctx, "Possible infiltration: new device(s)",
                        fresh.joinToString("\n") { "${it.ip}  ${it.mac}  ${it.vendor}" }
                    )
                } else {
                    Toast.makeText(ctx, "Scan done: ${found.size} devices, no unknown MACs.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun deepScan() {
        val ctx = context ?: return
        Toast.makeText(ctx, "Fingerprinting devices (read-only)...", Toast.LENGTH_SHORT).show()
        thread {
            val rows = mutableListOf<Device>()
            val notes = mutableMapOf<String, String>()

            val found = LanScanner.scan(ctx)
            val store = DeviceStore(ctx)
            val known = store.macSet()
            val fresh = found.filter { it.mac != "?" && it.mac !in known }
            store.addAll(found)
            rows.addAll(found)
            for (d in found) {
                val bits = mutableListOf<String>()
                Discovery.httpBanner(d.ip)?.let { bits.add(it) }
                Discovery.tlsCn(d.ip, 443)?.let { bits.add("TLS: $it") }
                Discovery.tlsCn(d.ip, 8443)?.let { bits.add("TLS: $it") }
                if (bits.isNotEmpty()) notes[d.ip] = bits.joinToString("\n")
            }

            val nsdResults = java.util.concurrent.CopyOnWriteArrayList<String>()
            val nsdDone = java.util.concurrent.CountDownLatch(1)
            activity?.runOnUiThread {
                Discovery.nsd(ctx, { nsdResults.add(it) }) { nsdDone.countDown() }
            }
            try { nsdDone.await(6, java.util.concurrent.TimeUnit.SECONDS) } catch (e: Exception) { }

            val ssdp = Discovery.ssdp(3000)

            activity?.runOnUiThread {
                adapter.data = rows
                adapter.newMacs = fresh.map { it.mac }.toSet()
                adapter.notes = notes
                adapter.services = nsdResults + ssdp
                adapter.notifyDataSetChanged()
                if (fresh.isNotEmpty()) {
                    NotificationHelper.alert(
                        ctx, "Possible infiltration: new device(s)",
                        fresh.joinToString("\n") { "${it.ip}  ${it.mac}  ${it.vendor}" }
                    )
                }
                Toast.makeText(
                    ctx,
                    "Deep scan: ${rows.size} hosts, ${nsdResults.size} mDNS, ${ssdp.size} SSDP",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}

class DeviceAdapter : RecyclerView.Adapter<DeviceAdapter.VH>() {
    var data: List<Device> = emptyList()
    var newMacs: Set<String> = emptySet()
    var notes: Map<String, String> = emptyMap()
    var services: List<String> = emptyList()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.title)
        val sub: TextView = v.findViewById(R.id.sub)
        val badge: TextView = v.findViewById(R.id.badge)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_device, p, false))

    override fun getItemCount() = data.size + if (services.isEmpty()) 0 else services.size + 1

    override fun onBindViewHolder(h: VH, pos: Int) {
        if (pos < data.size) {
            val d = data[pos]
            h.title.text = "${d.ip}   ${d.mac}"
            h.sub.text = notes[d.ip] ?: d.vendor
            h.badge.visibility = if (d.mac in newMacs) View.VISIBLE else View.GONE
        } else {
            h.title.text = if (pos == data.size) "Broadcast services (mDNS / SSDP)"
                           else services[pos - data.size - 1]
            h.sub.text = if (pos == data.size) "${services.size} discovered"
                         else "announced on this network"
            h.badge.visibility = View.GONE
        }
    }
}

// ---------------- Status tab ----------------

class StatusFragment : Fragment() {
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { refresh(); handler.postDelayed(this, 2000) }
    }

    override fun onCreateView(inflater: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val v = inflater.inflate(R.layout.frag_status, c, false)
        val act = activity as? MainActivity ?: return v

        v.findViewById<Button>(R.id.btnStart).setOnClickListener { act.startVpn() }
        v.findViewById<Button>(R.id.btnStop).setOnClickListener { act.stopVpn() }
        v.findViewById<Button>(R.id.btnExport).setOnClickListener { export() }

        val prefs = requireContext().getSharedPreferences("netsentry", 0)
        val auto = v.findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.swAuto)
        auto.isChecked = prefs.getBoolean("autostart", false)
        auto.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("autostart", on).apply() }

        // Router feed settings
        val rp = requireContext().getSharedPreferences("router", 0)
        val ip = v.findViewById<EditText>(R.id.etRouterIp)
        val token = v.findViewById<EditText>(R.id.etPiholeToken)
        val pw = v.findViewById<EditText>(R.id.etPiholePw)
        ip.setText(rp.getString("ip", "192.168.1.1"))
        token.setText(rp.getString("token", ""))
        pw.setText(rp.getString("password", ""))
        val swPi = v.findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.swPihole)
        val swLog = v.findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.swSyslog)
        swPi.isChecked = rp.getBoolean("use_pihole", false)
        swLog.isChecked = rp.getBoolean("use_syslog", false)

        v.findViewById<Button>(R.id.btnSaveRouter).setOnClickListener {
            rp.edit()
                .putString("ip", ip.text.toString().trim())
                .putString("token", token.text.toString().trim())
                .putString("password", pw.text.toString().trim())
                .putBoolean("use_pihole", swPi.isChecked)
                .putBoolean("use_syslog", swLog.isChecked)
                .apply()
            Toast.makeText(context, "Router feed saved. The running service picks it up within a minute.", Toast.LENGTH_LONG).show()
        }
        return v
    }

    override fun onResume() { super.onResume(); handler.post(tick) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(tick) }

    private fun refresh() {
        val v = view ?: return
        v.findViewById<TextView>(R.id.txtStatus).text =
            if (NetWatchService.running) "VPN: RUNNING (capture + ARP watch + router feed)" else "VPN: stopped"
        v.findViewById<TextView>(R.id.txtTransport).text =
            "Underlying transport: ${NetWatchService.currentTransport}"
        v.findViewById<TextView>(R.id.txtFlows).text =
            "Active flows: ${NetWatchService.flowCount}   Phone endpoints: ${NetWatchService.endpointsLogged}   Flagged: ${NetWatchService.flaggedLogged}"
        v.findViewById<TextView>(R.id.txtGateway).text =
            "Gateway: ${ArpWatch.gatewayBinding(requireContext())}"
        thread {
            val (count, unique) = EndpointDb(requireContext()).stats()
            val flagged = EndpointDb(requireContext()).flaggedCount()
            val lan = EndpointDb(requireContext()).lanCount()
            activity?.runOnUiThread {
                view?.findViewById<TextView>(R.id.txtStats)?.text =
                    "Database: $count connections, $unique unique destinations, $flagged flagged, $lan from LAN devices"
            }
        }
    }

    private fun export() {
        val ctx = context ?: return
        thread {
            val f = File(ctx.getExternalFilesDir(null), "endpoints.csv")
            f.writeText(EndpointDb(ctx).csv())
            activity?.runOnUiThread {
                Toast.makeText(ctx, "Exported to ${f.absolutePath}", Toast.LENGTH_LONG).show()
            }
        }
    }
}
