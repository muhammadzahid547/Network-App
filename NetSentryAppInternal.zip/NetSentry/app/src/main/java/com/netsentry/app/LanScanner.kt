
package com.netsentry.app

import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkProperties
import java.io.File
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

object LanScanner {

    fun gateway(ctx: Context): String? {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val nw = cm.activeNetwork ?: return null
        val lp: LinkProperties = cm.getLinkProperties(nw) ?: return null
        for (r in lp.routes) if (r.isDefaultRoute) return r.gateway?.hostAddress
        return null
    }

    fun isOnWifi(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)
    }

    fun scan(ctx: Context, onProgress: ((Int) -> Unit)? = null): List<Device> {
        val gw = gateway(ctx) ?: return emptyList()
        val prefix = gw.substringBeforeLast(".")
        val alive = ConcurrentHashMap.newKeySet<String>()
        val pool = Executors.newFixedThreadPool(32)
        val jobs = (1..254).map { i ->
            pool.submit {
                onProgress?.invoke(i)
                val ip = "$prefix.$i"
                try {
                    if (InetAddress.getByName(ip).isReachable(800)) {
                        alive.add(ip)
                    } else {
                        for (port in intArrayOf(80, 443, 22, 445, 8080, 7547)) {
                            try {
                                Socket().use { s ->
                                    s.connect(InetSocketAddress(ip, port), 200)
                                    alive.add(ip)
                                }
                                break
                            } catch (e: Exception) { }
                        }
                    }
                } catch (e: Exception) { }
            }
        }
        jobs.forEach { try { it.get() } catch (e: Exception) { } }
        pool.shutdown()
        val arp = parseArp()
        return alive.map { ip -> Device(ip, arp[ip] ?: "?") }.sortedBy { it.ip }
    }

    fun parseArp(): Map<String, String> {
        val map = HashMap<String, String>()
        try {
            File("/proc/net/arp").forEachLine { line ->
                val p = line.trim().split(Regex("\\s+"))
                if (p.size >= 4 && p[0].contains(".") &&
                    p[3] != "00:00:00:00:00:00" && p[3].contains(":")
                ) map[p[0]] = p[3]
            }
        } catch (e: Exception) { }
        return map
    }

    // Best-effort OUI map, extend freely. Unknown -> "Unknown vendor".
    fun vendor(mac: String): String {
        if (mac.length < 8) return "Unknown vendor"
        val oui = mac.substring(0, 8).uppercase()
        return when (oui) {
            "64:CC:2E", "AC:C1:EE", "9C:99:A0" -> "Xiaomi"
            "A4:83:E7", "F0:18:98", "8C:85:90", "AC:3C:0B" -> "Apple"
            "F4:F5:E8", "54:60:09" -> "Google"
            "E4:5F:01", "70:0F:6A" -> "Raspberry Pi"
            "B8:27:EB", "DC:A6:32" -> "Raspberry Pi"
            "FC:EC:DA" -> "Espressif (IoT)"
            "48:3F:DA" -> "Texas Instruments (IoT)"
            "A0:20:A6" -> "Espressif (IoT)"
            "30:AE:A4" -> "Espressif (IoT)"
            else -> "Unknown vendor"
        }
    }
}
