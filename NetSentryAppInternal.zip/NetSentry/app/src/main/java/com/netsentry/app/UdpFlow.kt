
package com.netsentry.app

import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.channels.DatagramChannel
import kotlin.concurrent.thread

class UdpFlow(
    val key: String,
    private val svc: NetWatchService,
    private val cip: String,
    private val dip: String,
    private val cport: Int,
    private val dport: Int
) {
    @Volatile var open = true
    @Volatile var lastActive = System.currentTimeMillis()
    private val ch = DatagramChannel.open()

    init {
        svc.protect(ch.socket())
        ch.connect(InetSocketAddress(dip, dport))
        thread {
            val buf = ByteArray(4096)
            while (open) {
                try {
                    val bb = ByteBuffer.wrap(buf)
                    ch.receive(bb) ?: continue
                    val n = bb.position()
                    if (n > 0) {
                        lastActive = System.currentTimeMillis()
                        svc.sendRaw(NetPacket.buildUdp4(dip, cip, dport, cport, buf.copyOf(n)))
                    }
                } catch (e: Exception) {
                    break
                }
            }
            close()
        }
    }

    fun onPayload(p: ByteArray) {
        lastActive = System.currentTimeMillis()
        try { ch.write(ByteBuffer.wrap(p)) } catch (e: Exception) { close() }
    }

    fun close() {
        if (!open) return
        open = false
        try { ch.close() } catch (e: Exception) { }
        svc.removeUdp(key)
    }
}
