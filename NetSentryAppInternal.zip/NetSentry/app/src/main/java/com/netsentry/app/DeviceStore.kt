
package com.netsentry.app

import android.content.Context

data class Device(val ip: String, val mac: String) {
    val vendor: String get() = LanScanner.vendor(mac)
}

// Remembers every MAC ever seen on your LAN. Any MAC that was never seen before
// is treated as a possible infiltration and raises an alert.
class DeviceStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("devices", Context.MODE_PRIVATE)

    fun macSet(): Set<String> =
        prefs.getStringSet("macs", emptySet())?.toSet() ?: emptySet()

    fun addAll(devs: List<Device>) {
        val s = macSet().toMutableSet()
        s.addAll(devs.map { it.mac })
        prefs.edit().putStringSet("macs", s).apply()
    }

    fun clear() = prefs.edit().remove("macs").apply()
}
