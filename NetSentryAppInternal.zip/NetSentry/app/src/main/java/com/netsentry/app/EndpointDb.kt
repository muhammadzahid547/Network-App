
package com.netsentry.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

// src = which device generated this endpoint: "phone" for our own capture,
// an IP like "192.168.1.23" for whole-network visibility via router feeds.
data class Endpoint(
    val id: Long,
    val ts: Long,
    val transport: String,
    val proto: String,
    val dst: String,
    val dport: Int,
    val domain: String?,
    val bytes: Long,
    val flag: String = "ok",
    val src: String = "phone"
)

class EndpointDb(ctx: Context) :
    SQLiteOpenHelper(ctx, "netsentry.db", null, 3) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE endpoints(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "ts INTEGER, transport TEXT, proto TEXT, dst TEXT," +
                "dport INTEGER, domain TEXT, bytes INTEGER, flag TEXT DEFAULT 'ok'," +
                "src TEXT DEFAULT 'phone')"
        )
        db.execSQL("CREATE INDEX idx_ts ON endpoints(id DESC)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldV: Int, newV: Int) {
        if (oldV < 2) try { db.execSQL("ALTER TABLE endpoints ADD COLUMN flag TEXT DEFAULT 'ok'") } catch (e: Exception) { }
        if (oldV < 3) try { db.execSQL("ALTER TABLE endpoints ADD COLUMN src TEXT DEFAULT 'phone'") } catch (e: Exception) { }
    }

    fun add(e: Endpoint) {
        val cv = ContentValues()
        cv.put("ts", e.ts)
        cv.put("transport", e.transport)
        cv.put("proto", e.proto)
        cv.put("dst", e.dst)
        cv.put("dport", e.dport)
        cv.put("domain", e.domain)
        cv.put("bytes", e.bytes)
        cv.put("flag", e.flag)
        cv.put("src", e.src)
        writableDatabase.insert("endpoints", null, cv)
    }

    fun recent(limit: Int = 500): List<Endpoint> {
        val out = ArrayList<Endpoint>()
        readableDatabase.rawQuery(
            "SELECT id,ts,transport,proto,dst,dport,domain,bytes,flag,src FROM endpoints ORDER BY id DESC LIMIT ?",
            arrayOf(limit.toString())
        ).use { c ->
            while (c.moveToNext()) {
                out.add(
                    Endpoint(
                        c.getLong(0), c.getLong(1), c.getString(2), c.getString(3),
                        c.getString(4), c.getInt(5), c.getString(6), c.getLong(7),
                        c.getString(8) ?: "ok", c.getString(9) ?: "phone"
                    )
                )
            }
        }
        return out
    }

    fun stats(): Pair<Int, Int> {
        var count = 0
        var unique = 0
        readableDatabase.rawQuery("SELECT COUNT(*), COUNT(DISTINCT dst) FROM endpoints", null).use { c ->
            if (c.moveToFirst()) { count = c.getInt(0); unique = c.getInt(1) }
        }
        return count to unique
    }

    fun flaggedCount(): Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM endpoints WHERE flag != 'ok'", null).use { c ->
            if (c.moveToFirst()) return c.getInt(0)
        }
        return 0
    }

    fun lanCount(): Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM endpoints WHERE src != 'phone'", null).use { c ->
            if (c.moveToFirst()) return c.getInt(0)
        }
        return 0
    }

    fun csv(): String {
        val sb = StringBuilder("timestamp,src,transport,proto,dst_ip,dst_port,domain,bytes,flag\n")
        readableDatabase.rawQuery(
            "SELECT ts,src,transport,proto,dst,dport,domain,bytes,flag FROM endpoints ORDER BY id", null
        ).use { c ->
            while (c.moveToNext()) {
                sb.append(c.getLong(0)).append(',')
                    .append(c.getString(1)).append(',')
                    .append(c.getString(2)).append(',')
                    .append(c.getString(3)).append(',')
                    .append(c.getString(4)).append(',')
                    .append(c.getInt(5)).append(',')
                    .append(c.getString(6) ?: "").append(',')
                    .append(c.getLong(7)).append(',')
                    .append(c.getString(8) ?: "ok").append('\n')
            }
        }
        return sb.toString()
    }
}
