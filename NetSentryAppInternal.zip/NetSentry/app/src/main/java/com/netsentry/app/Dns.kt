
package com.netsentry.app

// Minimal DNS query-name extractor. We see these because plain DNS (port 53)
// passes through our VPN tunnel as UDP, so no root or MITM is needed.
object Dns {
    fun queryNames(payload: ByteArray): List<String> {
        val out = mutableListOf<String>()
        try {
            if (payload.size < 12) return out
            val qd = ((payload[4].toInt() and 0xFF) shl 8) or (payload[5].toInt() and 0xFF)
            if (qd == 0 || qd > 8) return out
            var p = 12
            for (i in 0 until qd) {
                if (p >= payload.size) break
                val sb = StringBuilder()
                var len = payload[p].toInt() and 0xFF
                var hops = 0
                while (len > 0 && hops < 20) {
                    p++
                    if (p + len > payload.size) return out
                    if (sb.isNotEmpty()) sb.append('.')
                    sb.append(String(payload, p, len, Charsets.US_ASCII))
                    p += len
                    if (p >= payload.size) break
                    len = payload[p].toInt() and 0xFF
                    hops++
                }
                p++          // terminating zero
                if (sb.isNotEmpty()) out.add(sb.toString().lowercase())
                p += 4       // QTYPE + QCLASS
            }
        } catch (e: Exception) { }
        return out
    }
}
