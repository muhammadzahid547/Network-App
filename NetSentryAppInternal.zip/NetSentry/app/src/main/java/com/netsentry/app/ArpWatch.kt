
package com.netsentry.app

import android.content.Context

// Continuous, zero-privilege network-defense layer:
//  1. Gateway IP-MAC binding watch: a silent gateway MAC change on your own
//     WiFi is the classic symptom of ARP spoofing / man-in-the-middle.
//  2. ARP-table diff: any MAC we have never seen before is flagged as a
//     possible rogue device, checked continuously while the VPN runs.
object ArpWatch {
    private const val PREFS = "arpwatch"
    private const val KEY_GW_MAC = "gw_mac"
    private const val KEY_GW_IP = "gw_ip"

    fun tick(ctx: Context) {
        if (!LanScanner.isOnWifi(ctx)) return
        val gw = LanScanner.gateway(ctx) ?: return
        val arp = LanScanner.parseArp()
        val mac = arp[gw] ?: return

        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val oldIp = prefs.getString(KEY_GW_IP, null)
        val oldMac = prefs.getString(KEY_GW_MAC, null)

        if (oldMac == null) {
            prefs.edit().putString(KEY_GW_MAC, mac).putString(KEY_GW_IP, gw).apply()
            return
        }
        if (oldIp == gw && !oldMac.equals(mac, true)) {
            NotificationHelper.alert(
                ctx, "Possible ARP spoofing / MITM",
                "Gateway $gw changed MAC from $oldMac to $mac on the same network. " +
                    "A device on this LAN may be intercepting your traffic."
            )
        }
        prefs.edit().putString(KEY_GW_MAC, mac).putString(KEY_GW_IP, gw).apply()

        val store = DeviceStore(ctx)
        val known = store.macSet()
        val fresh = arp.values.filter { it != "?" && it !in known }.distinct()
        if (fresh.isNotEmpty()) {
            store.addAll(fresh.map { Device("?", it) })
            NotificationHelper.alert(
                ctx, "New device(s) joined your network (ARP)",
                fresh.joinToString("\n") { "$it - ${LanScanner.vendor(it) }" } +
                    "\n\nA device you have never seen before is on this WiFi."
            )
        }
    }

    fun gatewayBinding(ctx: Context): String {
        val gw = LanScanner.gateway(ctx) ?: return "no gateway"
        val mac = LanScanner.parseArp()[gw] ?: "?"
        return "$gw - $mac"
    }
}
