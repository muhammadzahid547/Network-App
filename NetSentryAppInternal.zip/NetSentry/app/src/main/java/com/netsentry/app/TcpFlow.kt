
package com.netsentry.app

import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.LinkedBlockingQueue
import kotlin.concurrent.thread

// Best-effort minimal user-space TCP relay for the VPN tunnel.
// Good enough for browsing/APIs; not a full RFC-793 stack (see README limitations).
class TcpFlow(
    val key: String,
    private val svc: NetWatchService,
    private val cip: String,   // client IP inside tunnel (10.8.0.2)
    private val dip: String,   // real destination server
    private val cport: Int,
    private val dport: Int,
    clientIsn: Long
) {
    companion object {
        const val FIN = 1; const val SYN = 2; const val RST = 4
        const val PSH = 8; const val ACK = 16
    }

    @Volatile var open = true
    @Volatile var connected = false
    @Volatile var lastActive = System.currentTimeMillis()
    val created = System.currentTimeMillis()

    var clientNext = (clientIsn + 1) and 0xFFFFFFFFL
    private var serverIsn = (System.nanoTime() and 0x7FFFFFFFL)
    var serverNext = (serverIsn + 1) and 0xFFFFFFFFL

    private val sk = Socket()
    private val pending = LinkedBlockingQueue<ByteArray>()
    private var domainLogged = false

    init {
        svc.protect(sk)
        // SYN-ACK immediately: client is waiting for the handshake reply.
        send(NetPacket.buildTcp4(dip, cip, dport, cport, serverIsn, clientNext, SYN or ACK, ByteArray(0), 65535))
        thread {
            try {
                sk.connect(InetSocketAddress(dip, dport), 15000)
                connected = true
                var b = pending.poll()
                while (b != null) { writeSock(b); b = pending.poll() }
                reader()
            } catch (e: Exception) {
                if (open) sendRst()
            } finally {
                close()
            }
        }
    }

    private fun writeSock(data: ByteArray) {
        synchronized(sk) {
            sk.getOutputStream().write(data)
            sk.getOutputStream().flush()
        }
    }

    private fun reader() {
        val buf = ByteArray(16384)
        while (open) {
            val n = try { sk.getInputStream().read(buf) } catch (e: Exception) { -1 }
            if (n < 0) break
            if (n > 0) {
                lastActive = System.currentTimeMillis()
                val pkt = NetPacket.buildTcp4(dip, cip, dport, cport, serverNext, clientNext, PSH or ACK, buf.copyOf(n), 65535)
                serverNext = (serverNext + n) and 0xFFFFFFFFL
                send(pkt)
            }
        }
        if (open) {
            send(NetPacket.buildTcp4(dip, cip, dport, cport, serverNext, clientNext, FIN or ACK, ByteArray(0), 65535))
            serverNext = (serverNext + 1) and 0xFFFFFFFFL
        }
        close()
    }

    @Synchronized
    fun onPacket(seq: Long, ack: Long, flags: Int, payload: ByteArray) {
        if (!open) return
        lastActive = System.currentTimeMillis()
        if (flags and RST != 0) { close(); return }

        if (payload.isNotEmpty()) {
            if (!domainLogged) {
                val sni = NetPacket.extractSni(payload)
                if (sni != null) {
                    svc.logDomain(dip, dport, sni)
                    domainLogged = true
                }
            }
            if (seq == clientNext) {
                clientNext = (clientNext + payload.size) and 0xFFFFFFFFL
                if (connected) writeSock(payload) else pending.offer(payload)
                sendAck()
            } else {
                sendAck() // duplicate ACK; triggers fast retransmit in client
            }
        }

        if (flags and FIN != 0) {
            val finSeq = (seq + payload.size) and 0xFFFFFFFFL
            if (finSeq == clientNext) {
                clientNext = (clientNext + 1) and 0xFFFFFFFFL
                sendAck()
                try { sk.shutdownOutput() } catch (e: Exception) { }
                if (!connected) close()
            }
        }
    }

    @Synchronized
    fun repeatSynAck(clientIsnNew: Long) {
        if (!open) return
        clientNext = (clientIsnNew + 1) and 0xFFFFFFFFL
        send(NetPacket.buildTcp4(dip, cip, dport, cport, serverIsn, clientNext, SYN or ACK, ByteArray(0), 65535))
    }

    fun sendAck() {
        send(NetPacket.buildTcp4(dip, cip, dport, cport, serverNext, clientNext, ACK, ByteArray(0), 65535))
    }

    fun sendRst() {
        send(NetPacket.buildTcp4(dip, cip, dport, cport, serverNext, clientNext, RST or ACK, ByteArray(0), 65535))
    }

    fun send(pkt: ByteArray) = svc.sendRaw(pkt)

    fun close() {
        if (!open) return
        open = false
        try { sk.close() } catch (e: Exception) { }
        svc.removeTcp(key)
    }
}
