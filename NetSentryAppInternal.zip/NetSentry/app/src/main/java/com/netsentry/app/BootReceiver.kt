
package com.netsentry.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = ctx.getSharedPreferences("netsentry", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("autostart", false)) return
        try {
            ContextCompat.startForegroundService(
                ctx,
                Intent(ctx, NetWatchService::class.java).setAction(NetWatchService.ACTION_START)
            )
        } catch (e: Exception) {
            // VPN consent may not have been granted yet; user opens the app once.
        }
    }
}
