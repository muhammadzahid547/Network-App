
package com.netsentry.app

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.concurrent.thread

class NetWatchService : VpnService() {

    companion object {
        const val ACTION_START = "com.netsentry.app.START"
        const val ACTION_STOP = "com.netsentry.app.STOP"
        @Volatile var running = false
        @Volatile var currentTransport = "unknown"
        @Volatile var flowCount = 0
        @Volatile var endpointsLogged = 0L
        @Volatile var flaggedLogged = 0L
        @Volatile var lanLogged = 0L
    }

    private var vpn: ParcelFileDescriptor? = null
    private var out: FileOutputStream? = null
    private val outLock = Any()
    private val tcp = ConcurrentHashMap<String, TcpFlow>()
    private val udp = ConcurrentHashMap<String, UdpFlow>()
    private val alertCooldown = ConcurrentHashMap<String, Long>()
    private val routerDedupe = ConcurrentHashMap.newKeySet<String>()
    private lateinit var db: EndpointDb
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var cm: ConnectivityManager
    private var netCallback: ConnectivityManager.NetworkCallback? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        NotificationHelper.ensureChannels(this)
        if (intent?.action == ACTION_STOP) { shutdown(); stopSelf(); return START_NOT_STICKY }
        startForeground(1, fgNotification())
        if (running) return START_STICKY
        db = EndpointDb(this)
        cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        watchTransport()
        running = true
        thread { runVpn() }
        thread { routerLoop() }     // Pi-hole + syslog whole-network feed
        return START_STICKY
    }

    private fun runVpn() {
        try {
            vpn = Builder()
                .setSession("NetSentry")
                .setMtu(1500)
                .addAddress("10.8.0.2", 32)
                .addRoute("0.0.0.0", 0)
                .addDnsServer("8.8.8.8")
                .addDnsServer("1.1.1.1")
                .establish()
            val fd = vpn?.fileDescriptor ?: return
            val input = FileInputStream(fd)
            out = FileOutputStream(fd)
            thread {
                while (running) {
                    try { ArpWatch.tick(this) } catch (e: Exception) { }
                    cleanup()
                    Thread.sleep(15000)
                }
            }
            val buf = ByteArray(32767)
            var tick = 0
            while (running) {
                val n = input.read(buf)
                if (n <= 0) break
                handlePacket(buf.copyOf(n))
                if (++tick % 200 == 0) {
                    val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    nm.notify(1, fgNotification())
                }
            }
        } catch (e: Exception) {
        } finally {
            shutdown()
            stopSelf()
        }
    }

    // ---------------- Router-level whole-network feed ----------------

    private fun routerLoop() {
        Thread.sleep(3000)
        while (running) {
            try {
                val prefs = getSharedPreferences("router", 0)
                val onWifi = LanScanner.isOnWifi(this)

                if (onWifi && prefs.getBoolean("use_syslog", false)) {
                    if (!SyslogListener.running) {
                        SyslogListener.start { line -> handleSyslog(line) }
                    }
                } else if (SyslogListener.running) {
                    SyslogListener.stop()
                }

                if (onWifi && prefs.getBoolean("use_pihole", false)) {
                    val ip = prefs.getString("ip", "192.168.1.1") ?: "192.168.1.1"
                    val qs = RouterApi.fetchPiHole(
                        ip,
                        prefs.getString("token", "")?.takeIf { it.isNotEmpty() },
                        prefs.getString("password", "")?.takeIf { it.isNotEmpty() }
                    )
                    var inserted = 0
                    for (q in qs) {
                        if (q.domain.isEmpty() || q.client.isEmpty()) continue
                        val key = "${q.client}|${q.domain}"
                        if (key in routerDedupe) continue
                        routerDedupe.add(key)
                        if (routerDedupe.size > 3000) routerDedupe.clear()
                        val flag = Intel.classify(q.domain)
                        lanLogged++
                        if (flag != "ok") {
                            flaggedLogged++
                            intelAlert("LAN device hit $flag", "${q.client} queried ${q.domain}")
                        }
                        io.execute {
                            db.add(Endpoint(0, if (q.ts > 0) q.ts else System.currentTimeMillis(),
                                "lan", "LAN-DNS", "router", 53, q.domain, 0, flag, q.client))
                        }
                        inserted++
                    }
                }
            } catch (e: Exception) { }
            Thread.sleep(60_000)
        }
        SyslogListener.stop()
    }

    private fun handleSyslog(line: String) {
        try {
            val (kind, a, b) = SyslogListener.parse(line) ?: return
            when (kind) {
                "dns", "block" -> {
                    val key = "$a|$b|sys"
                    if (key in routerDedupe) return
                    routerDedupe.add(key)
                    if (routerDedupe.size > 3000) routerDedupe.clear()
                    val flag = Intel.classify(b)
                    lanLogged++
                    if (flag != "ok") flaggedLogged++
                    io.execute {
                        db.add(Endpoint(0, System.currentTimeMillis(), "lan",
                            if (kind == "block") "LAN-BLOCK" else "LAN-DNS",
                            "router", 53, b, 0, flag, a))
                    }
                }
                "dhcp" -> {
                    // Learn devices straight from DHCP leases.
                    val store = DeviceStore(this)
                    if (b !in store.macSet()) {
                        store.addAll(listOf(Device(a, b)))
                        NotificationHelper.alert(this, "New DHCP lease on network", "$a - $b - ${LanScanner.vendor(b)}")
                    }
                }
            }
        } catch (e: Exception) { }
    }

    // ---------------- Packet handling ----------------

    private fun handlePacket(p: ByteArray) {
        try {
            if (p.size < 20 || !NetPacket.is4(p)) return
            val proto = NetPacket.proto4(p)
            val src = NetPacket.src4(p)
            val dst = NetPacket.dst4(p)
            val l4 = NetPacket.payload4(p)
            if (l4.size < 4) return
            val sport = NetPacket.l4src(l4)
            val dport = NetPacket.l4dst(l4)

            when (proto) {
                NetPacket.UDP -> {
                    val key = "$src:$sport>$dst:$dport"
                    var f = udp[key]
                    if (f == null) {
                        if (udp.size >= 512) return
                        log("UDP", dst, dport, null, p.size)
                        f = UdpFlow(key, this, src, dst, sport, dport)
                        udp[key] = f
                        flowCount = tcp.size + udp.size
                    }
                    if (l4.size > 8) {
                        val payload = l4.copyOfRange(8, l4.size)
                        if (dport == 53) Dns.queryNames(payload).forEach { logDns(it) }
                        f.onPayload(payload)
                    }
                }
                NetPacket.TCP -> handleTcp(src, dst, sport, dport, l4)
            }
        } catch (e: Exception) { }
    }

    private fun handleTcp(src: String, dst: String, sport: Int, dport: Int, t: ByteArray) {
        if (t.size < 20) return
        val flags = t[13].toInt() and 0xFF
        val seq = NetPacket.readU32(t, 4)
        val hlen = (t[12].toInt() and 0xF0) ushr 2
        if (hlen < 20 || hlen > t.size) return
        val payload = t.copyOfRange(hlen, t.size)
        val key = "$src:$sport>$dst:$dport"

        val syn = (flags and 0x02) != 0
        val ackf = (flags and 0x10) != 0
        if (syn && !ackf) {
            var f = tcp[key]
            if (f == null) {
                if (tcp.size >= 512) {
                    sendRaw(NetPacket.buildTcp4(src, dst, sport, dport, 0, (seq + 1) and 0xFFFFFFFFL, 0x14, ByteArray(0), 0))
                    return
                }
                log("TCP", dst, dport, null, 0)
                f = TcpFlow(key, this, src, dst, sport, dport, seq)
                tcp[key] = f
                flowCount = tcp.size + udp.size
            } else {
                f.repeatSynAck(seq)
            }
            return
        }
        tcp[key]?.onPacket(seq, NetPacket.readU32(t, 8), flags, payload)
    }

    private fun log(proto: String, dst: String, dport: Int, domain: String?, size: Int, flag: String = "ok") {
        endpointsLogged++
        if (flag != "ok") flaggedLogged++
        io.execute {
            db.add(Endpoint(0, System.currentTimeMillis(), currentTransport, proto, dst, dport, domain, size.toLong(), flag, "phone"))
        }
    }

    fun logDomain(dst: String, dport: Int, domain: String) {
        val flag = Intel.classify(domain)
        if (flag != "ok") intelAlert("Suspicious endpoint ($flag)", "$domain -> $dst:$dport")
        log("TLS", dst, dport, domain, 0, flag)
    }

    fun logDns(name: String) {
        val flag = Intel.classify(name)
        if (flag != "ok") intelAlert("Suspicious DNS ($flag)", name)
        log("DNS", "dns", 53, name, 0, flag)
    }

    private fun intelAlert(title: String, text: String) {
        val now = System.currentTimeMillis()
        val last = alertCooldown[text] ?: 0L
        if (now - last < 10 * 60_000) return
        alertCooldown[text] = now
        NotificationHelper.alert(this, title, text)
    }

    fun sendRaw(pkt: ByteArray) {
        val o = out ?: return
        synchronized(outLock) {
            try { o.write(pkt); o.flush() } catch (e: Exception) { }
        }
    }

    fun removeTcp(key: String) { tcp.remove(key); flowCount = tcp.size + udp.size }
    fun removeUdp(key: String) { udp.remove(key); flowCount = tcp.size + udp.size }

    private fun cleanup() {
        val now = System.currentTimeMillis()
        tcp.values.forEach { f ->
            val idle = now - f.lastActive
            val neverConnected = !f.connected && now - f.created > 20000
            if (idle > 120_000 || neverConnected) { if (neverConnected) f.sendRst(); f.close() }
        }
        udp.values.forEach { f -> if (now - f.lastActive > 120_000) f.close() }
    }

    private fun watchTransport() {
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return
                currentTransport = when {
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "cellular"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
                    else -> "other"
                }
            }
            override fun onLost(network: Network) { currentTransport = "unknown" }
        }
        try {
            cm.registerNetworkCallback(
                NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build(),
                cb
            )
            netCallback = cb
        } catch (e: Exception) { }
    }

    private fun fgNotification(): android.app.Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, NotificationHelper.CH_FG)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("NetSentry monitoring")
            .setContentText("transport=$currentTransport · flows=$flowCount · lan=$lanLogged · flagged=$flaggedLogged")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun shutdown() {
        running = false
        SyslogListener.stop()
        tcp.values.forEach { try { it.close() } catch (e: Exception) { } }
        udp.values.forEach { try { it.close() } catch (e: Exception) { } }
        tcp.clear(); udp.clear(); flowCount = 0
        try { netCallback?.let { cm.unregisterNetworkCallback(it) } } catch (e: Exception) { }
        try { vpn?.close() } catch (e: Exception) { }
        vpn = null
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    override fun onDestroy() { shutdown() }
}
