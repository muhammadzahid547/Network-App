
package com.netsentry.app

// Minimal IPv4 TCP/UDP packet parsing + building (user-space NAT for the VPN engine)
object NetPacket {
    const val TCP = 6
    const val UDP = 17

    fun is4(b: ByteArray) = (b[0].toInt() shr 4) == 4
    fun ihl4(b: ByteArray) = (b[0].toInt() and 0xF) * 4
    fun totalLen4(b: ByteArray) = ((b[2].toInt() and 0xFF) shl 8) or (b[3].toInt() and 0xFF)
    fun proto4(b: ByteArray) = b[9].toInt() and 0xFF

    fun src4(b: ByteArray): String =
        "${b[12].toInt() and 0xFF}.${b[13].toInt() and 0xFF}.${b[14].toInt() and 0xFF}.${b[15].toInt() and 0xFF}"

    fun dst4(b: ByteArray): String =
        "${b[16].toInt() and 0xFF}.${b[17].toInt() and 0xFF}.${b[18].toInt() and 0xFF}.${b[19].toInt() and 0xFF}"

    fun payload4(b: ByteArray): ByteArray {
        val end = totalLen4(b)
        if (end <= ihl4(b) || end > b.size) return ByteArray(0)
        return b.copyOfRange(ihl4(b), end)
    }

    fun l4src(b: ByteArray): Int = ((b[0].toInt() and 0xFF) shl 8) or (b[1].toInt() and 0xFF)
    fun l4dst(b: ByteArray): Int = ((b[2].toInt() and 0xFF) shl 8) or (b[3].toInt() and 0xFF)

    fun readU16(b: ByteArray, off: Int) = ((b[off].toInt() and 0xFF) shl 8) or (b[off + 1].toInt() and 0xFF)

    fun readU32(b: ByteArray, off: Int): Long =
        ((b[off].toLong() and 0xFF) shl 24) or ((b[off + 1].toLong() and 0xFF) shl 16) or
        ((b[off + 2].toLong() and 0xFF) shl 8) or (b[off + 3].toLong() and 0xFF)

    fun partialSum(d: ByteArray, off: Int, len: Int, seed: Long): Long {
        var sum = seed
        var i = off
        val end = off + len
        while (i + 1 < end) {
            sum += (((d[i].toInt() and 0xFF) shl 8) or (d[i + 1].toInt() and 0xFF)).toLong()
            i += 2
        }
        if (i < end) sum += ((d[i].toInt() and 0xFF) shl 8).toLong()
        return sum
    }

    fun checksum(d: ByteArray, off: Int, len: Int): Int {
        var s = partialSum(d, off, len, 0)
        while (s ushr 16 != 0L) s = (s and 0xFFFF) + (s ushr 16)
        return (s.inv() and 0xFFFF).toInt()
    }

    private fun writeIp(p: ByteArray, off: Int, ip: String) {
        val parts = ip.split(".")
        if (parts.size != 4) return
        for (i in 0..3) p[off + i] = parts[i].toInt().toByte()
    }

    private fun fillIp4(p: ByteArray, srcIp: String, dstIp: String, proto: Int, total: Int) {
        p[0] = 0x45
        p[1] = 0
        p[2] = (total shr 8).toByte(); p[3] = total.toByte()
        p[4] = 0; p[5] = 1   // id
        p[6] = 0x40.toByte(); p[7] = 0  // DF
        p[8] = 64; p[9] = proto.toByte()
        writeIp(p, 12, srcIp); writeIp(p, 16, dstIp)
        val cs = checksum(p, 0, 20)
        p[10] = (cs shr 8).toByte(); p[11] = cs.toByte()
    }

    private fun tcpChecksum4(p: ByteArray, srcIp: String, dstIp: String, l4len: Int): Int {
        val pseudo = ByteArray(12)
        writeIp(pseudo, 0, srcIp); writeIp(pseudo, 4, dstIp)
        pseudo[9] = TCP.toByte()
        pseudo[10] = (l4len shr 8).toByte(); pseudo[11] = l4len.toByte()
        var s = partialSum(pseudo, 0, 12, 0)
        s = partialSum(p, 20, l4len, s)
        while (s ushr 16 != 0L) s = (s and 0xFFFF) + (s ushr 16)
        return (s.inv() and 0xFFFF).toInt()
    }

    fun buildTcp4(
        srcIp: String, dstIp: String, sport: Int, dport: Int,
        seq: Long, ack: Long, flags: Int, payload: ByteArray, win: Int
    ): ByteArray {
        val total = 20 + 20 + payload.size
        val p = ByteArray(total)
        fillIp4(p, srcIp, dstIp, TCP, total)
        val off = 20
        p[off] = (sport shr 8).toByte(); p[off + 1] = sport.toByte()
        p[off + 2] = (dport shr 8).toByte(); p[off + 3] = dport.toByte()
        val s32 = seq and 0xFFFFFFFFL
        val a32 = ack and 0xFFFFFFFFL
        p[off + 4] = (s32 ushr 24).toByte(); p[off + 5] = (s32 ushr 16).toByte()
        p[off + 6] = (s32 ushr 8).toByte(); p[off + 7] = s32.toByte()
        p[off + 8] = (a32 ushr 24).toByte(); p[off + 9] = (a32 ushr 16).toByte()
        p[off + 10] = (a32 ushr 8).toByte(); p[off + 11] = a32.toByte()
        p[off + 12] = (5 shl 4).toByte()
        p[off + 13] = flags.toByte()
        p[off + 14] = (win shr 8).toByte(); p[off + 15] = win.toByte()
        System.arraycopy(payload, 0, p, off + 20, payload.size)
        val cs = tcpChecksum4(p, srcIp, dstIp, 20 + payload.size)
        p[off + 16] = (cs shr 8).toByte(); p[off + 17] = cs.toByte()
        return p
    }

    fun buildUdp4(srcIp: String, dstIp: String, sport: Int, dport: Int, payload: ByteArray): ByteArray {
        val total = 20 + 8 + payload.size
        val p = ByteArray(total)
        fillIp4(p, srcIp, dstIp, UDP, total)
        val off = 20
        p[off] = (sport shr 8).toByte(); p[off + 1] = sport.toByte()
        p[off + 2] = (dport shr 8).toByte(); p[off + 3] = dport.toByte()
        val ulen = 8 + payload.size
        p[off + 4] = (ulen shr 8).toByte(); p[off + 5] = ulen.toByte()
        System.arraycopy(payload, 0, p, off + 8, payload.size)
        val pseudo = ByteArray(12)
        writeIp(pseudo, 0, srcIp); writeIp(pseudo, 4, dstIp)
        pseudo[9] = UDP.toByte()
        pseudo[10] = (ulen shr 8).toByte(); pseudo[11] = ulen.toByte()
        var s = partialSum(pseudo, 0, 12, 0)
        s = partialSum(p, off, ulen, s)
        while (s ushr 16 != 0L) s = (s and 0xFFFF) + (s ushr 16)
        val cs = (s.inv() and 0xFFFF).toInt()
        p[off + 6] = (cs shr 8).toByte(); p[off + 7] = cs.toByte()
        return p
    }

    // Extract SNI (server_name) from a TLS ClientHello, if this payload is one.
    fun extractSni(t: ByteArray): String? {
        try {
            if (t.size < 44) return null
            if (t[0].toInt() != 22) return null          // not a TLS handshake record
            if (t[5].toInt() != 1) return null           // not ClientHello
            var p = 5 + 4 + 2 + 32                        // record+hs hdr, version, random
            p += 1 + (t[p].toInt() and 0xFF)              // session id
            val csLen = readU16(t, p); p += 2 + csLen     // cipher suites
            p += 1 + (t[p].toInt() and 0xFF)              // compression methods
            val extEnd = p + 2 + readU16(t, p)
            p += 2
            while (p + 4 <= extEnd && p + 4 <= t.size) {
                val type = readU16(t, p)
                val len = readU16(t, p + 2)
                p += 4
                if (type == 0 && p + 5 <= t.size) {        // server_name ext
                    var q = p + 2                            // server_name_list len
                    q += 1                                   // name type
                    val nameLen = readU16(t, q); q += 2
                    if (q + nameLen <= t.size)
                        return String(t, q, nameLen, Charsets.US_ASCII)
                }
                p += len
            }
        } catch (e: Exception) { }
        return null
    }
}
